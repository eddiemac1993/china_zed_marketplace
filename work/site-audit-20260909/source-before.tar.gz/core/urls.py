from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path("profile/products/<int:product_id>/homepage/", views.staff_product_homepage_view, name="staff_product_homepage"),
    # Home
    path("", views.home, name="home"),
    # django-webpush registers its own url named "service_worker"; since it is
    # included after this one it wins reverse(), so keep a distinct name here
    path("service-worker.js", views.service_worker_view, name="chinazed_service_worker"),
    path("about/", views.about, name="about"),
    path("advertise/", views.advertise_view, name="advertise"),
    path("advertise/success/<int:ad_id>/", views.advertise_success_view, name="advertise_success"),
    path("faq/", views.faq, name="faq"),
    path("terms/", views.terms, name="terms"),
    path("privacy/", views.privacy, name="privacy"),
    path("assistant/", views.assistant_view, name="assistant"),
    path("assistant/chat/", views.assistant_chat_view, name="assistant_chat"),
    path("search/suggestions/", views.search_suggestions_view, name="search_suggestions"),
    path("recommendations/", views.home_recommendations_view, name="home_recommendations"),

    # Auth
    path("register/", views.register_view, name="register"),
    path("register/check-email/", views.registration_pending_view, name="registration_pending"),
    path("register/resend-activation/", views.resend_activation_view, name="resend_activation"),
    path("activate/<uidb64>/<token>/", views.activate_account_view, name="activate_account"),
    path("login/", views.ChinaZedLoginView.as_view(), name="login"),
    path("logout/", views.logout_view, name="logout"),

    # Profile
    path("profile/", views.profile_view, name="profile"),
    path("profile/products/<int:product_id>/publish/", views.staff_quick_publish_product_view, name="staff_quick_publish_product"),
    path("profile/products/<int:product_id>/split/", views.staff_split_product_view, name="staff_split_product"),
    path("profile/products/<int:product_id>/split-photo/<int:image_id>/analyze/", views.staff_analyze_split_photo_view, name="staff_analyze_split_photo"),
    path("profile/products/<int:product_id>/update/", views.staff_update_shop_product_view, name="staff_update_shop_product"),
    path("profile/products/<int:product_id>/delete/", views.staff_delete_shop_product_view, name="staff_delete_shop_product"),

    # Products
    path("product/<slug:slug>/", views.product_detail, name="product_detail"),
    path("product/<slug:slug>/whatsapp/", views.product_whatsapp_view, name="product_whatsapp"),
    path("product/<slug:slug>/save/", views.toggle_wishlist_view, name="toggle_wishlist"),
    path("saved/", views.wishlist_view, name="wishlist"),
    path("product/<slug:slug>/order/", views.place_order_view, name="place_order"),
    path("request-product/", views.request_product_view, name="request_product"),

    # =========================
    # CART SYSTEM
    # =========================

    # View cart
    path("cart/", views.cart_view, name="cart"),

    # Add to cart
    path("cart/add/<slug:slug>/", views.add_to_cart_view, name="add_to_cart"),

    # Update quantity (increase/decrease)
    path("cart/update/<int:item_id>/", views.update_cart_item_view, name="update_cart_item"),

    # Remove item
    path("cart/remove/<int:item_id>/", views.remove_cart_item_view, name="remove_cart_item"),

    # Clear entire cart
    path("cart/clear/", views.clear_cart_view, name="clear_cart"),

    # Checkout cart → create order
    path("cart/checkout/", views.checkout_cart_view, name="checkout_cart"),

    # =========================
    # ORDERS
    # =========================

    path("order/<int:order_id>/", views.order_detail_view, name="order_detail"),
    path("order/<int:order_id>/cancel-availability/", views.cancel_after_availability_view, name="cancel_after_availability"),
    path("order/<int:order_id>/receipt/", views.receipt_view, name="receipt"),
    path("order/<int:order_id>/receipt/pdf/", views.receipt_pdf_view, name="receipt_pdf"),

    # =========================
    # SUPPLIER
    # =========================

    path("supplier/submit-product/", views.supplier_submit_product, name="supplier_submit_product"),
    path("supplier/import-product/", views.marketplace_import_preview_view, name="marketplace_import_preview"),
    path("supplier/import-taobao/", views.taobao_import_preview_view, name="taobao_import_preview"),
    path("supplier/analyze-photo/", views.analyze_product_photo_view, name="analyze_product_photo"),

    # =========================
    # BIKER DELIVERY NETWORK
    # =========================

    path("become-a-biker/", views.become_biker_view, name="become_biker"),
    path("biker/dashboard/", views.biker_dashboard_view, name="biker_dashboard"),
    path("biker/jobs/<int:job_id>/accept/", views.biker_accept_job_view, name="biker_accept_job"),
    path("biker/jobs/<int:job_id>/picked-up/", views.biker_mark_picked_up_view, name="biker_mark_picked_up"),
    path("biker/jobs/<int:job_id>/delivered/", views.biker_mark_delivered_view, name="biker_mark_delivered"),

    # =========================
    # POLICY
    # =========================

    path("order-policy/", views.order_policy, name="order_policy"),

    path(
        "order/<int:order_id>/upload-payment-proof/",
        views.upload_payment_proof_view,
        name="upload_payment_proof"
    ),

    path(
        "product/<slug:slug>/save-image/",
        views.save_product_image_view,
        name="save_product_image"
    ),
]
